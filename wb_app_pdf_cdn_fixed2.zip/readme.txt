W&BRotorcraft — PWA v5 (fixed)
=================================
Four sections: Balance A, B, C, and Chord Value (read-only, mirrors C, has its own moment).
Totals use A+B+C only; chord metrics unchanged. Works offline.

Deploy on TiinyHost:
1) Go to https://tiiny.host/host-html-file
2) Upload ALL files from this folder.
3) Publish and copy the HTTPS link.
4) On iPhone: open link in Safari → Share → Add to Home Screen.
